Hooks:PostHook( DOTManager, "create_dot_data", "DotManager", function(self, type, custom_data)
	local dot_data = Hooks:GetReturn()
		
	if custom_data and custom_data.dot_trigger_chance then
		dot_data.dot_trigger_chance = custom_data.dot_trigger_chance
	end
	
	return dot_data

end  )