Hooks:PostHook(DOTTweakData, "init", "DotTweakData", function(self)

self.dot_entries.poison.ammo_rip.dot_length = 2
self.dot_entries.poison.ammo_rip.dot_damage = 9
self.dot_entries.poison.ammo_rip.dot_tick_period = 0.5
self.dot_entries.poison.ammo_rip.dot_grace_period = 0.3
self.dot_entries.poison.ammo_rip.dot_trigger_chance = 0.4

end)