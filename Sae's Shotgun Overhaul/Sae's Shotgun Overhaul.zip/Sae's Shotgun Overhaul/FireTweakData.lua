Hooks:PostHook(FireTweakData, "init", "FireTweakData", function(self)

self.dot_entries.fire.ammo_dragons_breath.dot_damage = 12
self.dot_entries.fire.ammo_dragons_breath.dot_length = 3.6
self.dot_entries.fire.ammo_dragons_breath.dot_trigger_max_distance = 2000
self.dot_entries.fire.ammo_dragons_breath.dot_grace_period = 0.3

end)