Hooks:PostHook(CopDamage, "damage_dot", "OverkillRevert", function(self, attack_data)

if not (attack_data.result == nil) then
	if attack_data.result.type == "death" then
		local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
		if not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and attack_data.attacker_unit == managers.player:player_unit() and alive(attack_data.weapon_unit) and attack_data.weapon_unit:base():is_category("shotgun", "saw") then
			managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
		end
	end
end

end)