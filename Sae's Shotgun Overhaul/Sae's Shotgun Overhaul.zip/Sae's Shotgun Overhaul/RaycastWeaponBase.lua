local start_dot_damage = DOTBulletBase.start_dot_damage
function DOTBulletBase:start_dot_damage(col_ray, weapon_unit, dot_data, ...)
    dot_data = dot_data or self.DOT_DATA

    if not dot_data.dot_trigger_chance or math.random() < dot_data.dot_trigger_chance then
        return start_dot_damage(self, col_ray, weapon_unit, dot_data, ...)
    end
end

function DOTBulletBase:_dot_data_by_weapon(weapon_unit)
	local weap_base = alive(weapon_unit) and weapon_unit:base()
	local ammo_data = weap_base.ammo_data and weap_base:ammo_data()
	local ammo_dot_data = ammo_data and ammo_data.dot_data
	if ammo_dot_data then
		return managers.dot:create_dot_data(ammo_dot_data.type, ammo_dot_data.custom_data)
	end

	return nil
end