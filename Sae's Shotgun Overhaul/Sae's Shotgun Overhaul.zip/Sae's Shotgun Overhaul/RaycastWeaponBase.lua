local start_dot_damage = DOTBulletBase.start_dot_damage
function DOTBulletBase:start_dot_damage(col_ray, weapon_unit, dot_data, ...)
    dot_data = dot_data or tweak_data.dot:get_dot_data(self.DOT_DATA_NAME)

    if not dot_data.dot_trigger_chance or math.random() < dot_data.dot_trigger_chance then
        return start_dot_damage(self, col_ray, weapon_unit, dot_data, ...)
    end
end