Hooks:PostHook( WeaponTweakData, "init", "ShotgunOverhaul", function(self)

--PRIMARIES
--Reinfeld 880 
self.r870.stats.damage = 120
self.r870.stats.concealment = 14
self.r870.stats.reload = 12
self.boot.stats.spread = 10
self.r870.CLIP_AMMO_MAX = 8
self.r870.AMMO_PICKUP = {0.77, 1.88}

--Izhma 12G
self.saiga.stats.damage = 55
self.saiga.stats.concealment = 9
self.saiga.AMMO_PICKUP = {2.6, 4}

--Mosconi 12G Double Barrel
self.huntsman.stats.damage = 166
self.huntsman.stats_modifiers = {damage = 3}
self.huntsman.stats.spread = 14
self.huntsman.fire_mode_data.fire_rate = 60/100
self.huntsman.AMMO_MAX = 20
self.huntsman.AMMO_PICKUP = {0.09, 0.69}

--Breaker 12G
self.boot.stats.damage = 155
self.boot.fire_mode_data.fire_rate = 60/90
self.boot.AMMO_MAX = 48
self.boot.AMMO_PICKUP = {0.6, 1.52}
self.boot.stats.spread = 11

--Mosconi 12G Tactical
self.m590.stats.damage = 120
self.m590.stats.spread = 11
self.m590.stats.concealment = 17
self.m590.fire_mode_data.fire_rate = 60 / 110
self.m590.AMMO_PICKUP = {0.69, 1.84}

--M1014
self.benelli.stats.damage = 75
self.benelli.AMMO_PICKUP = {2.6, 4.2}

--Raven
self.ksg.stats.damage = 140
self.ksg.AMMO_MAX = 40
self.ksg.AMMO_PICKUP = {0.53, 1.49}
self.ksg.stats.reload = 14

--Reinfeld 88
self.m1897.stats.damage = 155
self.m1897.AMMO_MAX = 48
self.m1897.AMMO_PICKUP = {0.68, 1.55}
self.m1897.stats.reload = 12

--Steakout 12G
self.aa12.stats.damage = 60
self.aa12.stats.concealment = 13
self.aa12.AMMO_PICKUP = {2.8, 4.2}

--VD-12
self.sko12.stats.damage = 70
self.sko12.stats.concealment = 1
self.sko12.AMMO_MAX = 84
self.sko12.AMMO_PICKUP = {3.6, 5.4}

--Predator 12G
self.spas12.stats.damage = 75
self.spas12.AMMO_PICKUP = {2.66, 4.32}

--Joceline O/U 12G
self.b682.stats.damage = 166
self.b682.stats_modifiers = {damage = 3}
self.b682.stats.concealment = 12
self.b682.stats.spread = 14
self.b682.fire_mode_data.fire_rate = 60/100
self.b682.AMMO_MAX = 20
self.b682.AMMO_PICKUP = {0.09, 0.69}

--Deimos
self.supernova.stats.damage = 120
self.supernova.stats.concealment = 14
self.supernova.AMMO_MAX = 50
self.supernova.AMMO_PICKUP = {1.1, 1.75}
self.supernova.stats.reload = 13

--AKIMBOS
--Akimbo Goliath 12G
self.x_rota.stats.damage = 55
self.x_rota.AMMO_MAX = 63
self.x_rota.AMMO_PICKUP = {2.2, 3.3}
self.x_rota.stats.concealment = 9
self.x_rota.stats.reload = 7

--Akimbo Judge
--placeholder

--Akimbo Brothers Grimm 12G
self.x_basset.stats.damage = 30
self.x_basset.CLIP_AMMO_MAX = 14
self.x_basset.AMMO_MAX = 64
self.x_basset.AMMO_PICKUP = {2.5, 4.4}
self.x_basset.stats.spread = 7
self.x_basset.stats.concealment = 13
self.x_basset.stats.reload = 7

--Akimbo VD-12
self.x_sko12.CLIP_AMMO_MAX = 16
self.x_sko12.AMMO_PICKUP = {2.3, 3.6}
self.x_sko12.stats.spread = 10
self.x_sko12.stats.concealment = 9
self.x_sko12.stats.reload = 7

--SECONDARIES
--Locomotive 12G
self.serbu.stats.damage = 105
self.serbu.AMMO_MAX = 30
self.serbu.AMMO_PICKUP = {0.42, 1.47}

--Goliath 12G
self.rota.stats.damage = 55
self.rota.AMMO_MAX = 42
self.rota.AMMO_PICKUP = {1.6, 2.8}
self.rota.stats.concealment = 15

--Grimm 12G
self.basset.stats.damage = 30
self.basset.AMMO_MAX = 48
self.basset.AMMO_PICKUP = {1.6, 4.3}
self.basset.stats.spread = 7
self.basset.stats.recoil = 10
self.basset.stats.concealment = 17

--Claire 12G
self.coach.stats.damage = 166
self.coach.stats_modifiers = {damage = 3}
self.coach.fire_mode_data.fire_rate = 60/100
self.coach.AMMO_MAX = 12
self.coach.AMMO_PICKUP = {0.08, 0.6}
self.coach.stats.spread = 17

--GSPS 12G
self.m37.stats.damage = 130
self.m37.AMMO_MAX = 21
self.m37.AMMO_PICKUP = {0.34, 1.02}
self.m37.stats.concealment = 20

--Street Sweeper
self.striker.stats.damage = 60
self.striker.stats.concealment = 18
self.striker.stats.spread = 10
self.striker.stats.recoil = 10
self.striker.AMMO_MAX = 36
self.striker.AMMO_PICKUP = {2.1, 3.45}
self.striker.stats.reload = 14

--Argos III
self.ultima.stats.damage = 70
self.ultima.stats.reload = 9
self.ultima.stats.concealment = 16
self.ultima.AMMO_PICKUP = {1.9, 3.1}

--Judge
self.judge.stats.damage = 108
self.judge.AMMO_MAX = 20
self.judge.AMMO_PICKUP = {0.16, 0.51}

--damage falloff, rays repair, and hidden falloff removal

local SHOTGUN_FALL_PRIMARY_LOW = {
	optimal_distance = 800,
	optimal_range = 700,
	near_falloff = 0,
	far_falloff = 1500,
	near_multiplier = 1,
	far_multiplier = 0.7
}

for weap_id, weap_data in pairs(self) do
	if type(weap_data) == "table" and weap_data.stats then
		local cat_map = table.list_to_set(weap_data.categories)
		if cat_map.shotgun then
			weap_data.damage_falloff = SHOTGUN_FALL_PRIMARY_LOW
			weap_data.rays = 12
			weap_data.damage_near = 10000
			weap_data.damage_far = 10000
		end
	end
end

end )